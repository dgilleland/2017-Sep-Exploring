A Pen created at CodePen.io. You can find this one at https://codepen.io/Fahscinate/pen/IEhbu.

 A 3D grid of hexagon tiles with a hover/click.

inspired by (http://aprilzero.com/explorer/august-2014/)