A Pen created at CodePen.io. You can find this one at https://codepen.io/Chmood/pen/BKxNqg.

 Hexagonal grids, for the win!

Massive kudos to Amit Patel  (redblobgames.com)
=> http://www.redblobgames.com/grids/hexagons/

Code adapted from his early implementation => http://www.redblobgames.com/grids/hexagons/codegen/output/lib.js

My take :
* ES6 enabled
* x,y,z for Cubic Coords too (may be rolled back)
* camelCase everywhere
* merged flat/pointy topped hex/offset conversion helpers

* ugly procedural heightmapped terrain for now
* A* pathfinding