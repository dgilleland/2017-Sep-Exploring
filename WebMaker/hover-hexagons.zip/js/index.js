$(function() {
    var winW = window.innerWidth;
    var winH = window.innerHeight;
    var hexH,
        hexW,
        hexRadius,
        hexRectangleH,
        hexRectangleW,
        hexAngle = 0.52359,
        sideLength = winW / 30;

    var canvas = document.querySelector('#canvas');
    var blurCanvas = document.querySelector('#blur');

    var frameIndex;
    var points = [];
    var isAnimating = false;
    var currentCoord;


    var ctx = canvas.getContext('2d');
    ctx.strokeStyle = "#FF0000";
    var ctx2 = blurCanvas.getContext('2d');
    ctx2.strokeStyle = "#5CE6E6";
    canvas.width = winW;
    canvas.height = winH;
    blurCanvas.width = winW;
    blurCanvas.height = winH;
    hexH = Math.sin(hexAngle) * sideLength;
    hexRadius = Math.cos(hexAngle) * sideLength;

    hexRectangleW = 2 * hexRadius;
    hexRectangleH = hexH * 2 + sideLength;

    function calculateVerticies(x, y) {
        var verticies = [];

        verticies.push({
            x: x + hexRadius,
            y: y
        });

        verticies.push({
            x: x + hexRectangleW,
            y: y + hexH
        });

        verticies.push({
            x: x + hexRectangleW,
            y: y + hexH + sideLength
        });

        verticies.push({
            x: x + hexRadius,
            y: y + hexRectangleH
        });

        verticies.push({
            x: x,
            y: y + sideLength + hexH
        });

        verticies.push({
            x: x,
            y: y + hexH
        });

        verticies.push({
            x: x + hexRadius,
            y: y
        });

        return verticies;
    }

    function calculateWaypoints(vertices) {
        var waypoints = [];
        for (var i = 1; i < vertices.length; i++) {
            var pt0 = vertices[i - 1];
            var pt1 = vertices[i];
            var dx = pt1.x - pt0.x;
            var dy = pt1.y - pt0.y;
            for (var j = 0; j < 3; j++) {
                var x = pt0.x + dx * j / 3;
                var y = pt0.y + dy * j / 3;
                waypoints.push({
                    x: x,
                    y: y
                });
            }

        }
        waypoints.push({
            x: waypoints[0].x,
            y: waypoints[0].y
        });
        return (waypoints);
    }


    function drawHexagon(context, x, y, color, lineWidth, fill) {

        context.beginPath();
        context.strokeStyle = color;
        context.lineWidth = lineWidth;
        var verts = calculateVerticies(x, y);
        var vertCount = 4;

        if (fill) {
            vertCount = verts.length;
        }

        context.moveTo(verts[0].x, verts[0].y);
        for (var i = 1; i < vertCount; i++) {
            context.lineTo(verts[i].x, verts[i].y);
        }
        context.stroke();
    }

    function animate() {
        if (frameIndex < points.length) {
            requestAnimationFrame(animate);
        }
        else {
            isAnimating = false;
        }
        // to the current waypoint
        if (typeof points[frameIndex] !== 'undefined') {
            ctx2.beginPath();
            ctx2.moveTo(points[frameIndex - 1].x, points[frameIndex - 1].y);
            ctx2.lineTo(points[frameIndex].x, points[frameIndex].y);
            ctx2.stroke();
        }
        frameIndex++;
    }

    function animateHexagon(context, x, y, color, lineWidth, fill) {
        isAnimating = true;
        ctx2.beginPath();
        ctx2.strokeStyle = color;
        ctx2.lineWidth = lineWidth;
        frameIndex = 1
        var verts = calculateVerticies(x, y);
        points = calculateWaypoints(verts);
        animate();

    }

    function drawGrid() {
        var width = Math.floor(winW / hexRectangleW) + 1;
        var height = Math.floor(winH / (hexH * 2)) + 1;
        for (var i = -1; i < width; i++) {
            for (var j = -1; j < height; j++) {
                var x = i * hexRectangleW + ((j % 2) * hexRadius);
                var y = j * (sideLength + hexH);
                drawHexagon(ctx, x, y, '#5CE6E6', 1, false);
                //drawHexagon(ctx2, x,y, '#5CE6E6', 4, false);

            }

        }

    }


    function onWindowResize() {
        winW = window.innerWidth;
        winH = window.innerHeight;
        canvas.width = winW;
        canvas.height = winH;
        blurCanvas.width = winW;
        blurCanvas.height = winH;
        sideLength = winW / 30;
        hexH = Math.sin(hexAngle) * sideLength;
        hexRadius = Math.cos(hexAngle) * sideLength;
        hexRectangleW = 2 * hexRadius;
        hexRectangleH = hexH * 2 + sideLength;
        drawGrid();
    }

    function onMouseMove(e) {
        if (isAnimating) {
            return;
        }
        var x, y, hexX, hexY, screenX, screenY;
        x = e.offsetX || e.LayerX;
        y = e.offsetY || e.LayerY;

        hexY = Math.floor(y / (hexH + sideLength));
        hexX = Math.floor((x - (hexY % 2) * hexRadius) / hexRectangleW);

        screenX = hexX * hexRectangleW + ((hexY % 2) * hexRadius);
        screenY = hexY * (hexH + sideLength);
        
        if (typeof currentCoord == 'undefined' || currentCoord.x != screenX || currentCoord.y != screenY) {
            currentCoord = {
                x:screenX,
                y:screenY
            };
            ctx2.clearRect(0, 0, canvas.width, canvas.height);
            animateHexagon(ctx2, screenX, screenY, '#5CE6E6', 4, true);
        }

        //console.log(screenX, currentCoord.x,  screenY, currentCoord.y);


        //drawHexagon(ctx, screenX, screenY, '#00FF00', 4, true);
        //animateHexagon(ctx2, screenX, screenY, '#5CE6E6', 4, true);

    }

    window.addEventListener('resize', onWindowResize, false);
    canvas.addEventListener('mousemove', onMouseMove, false);
    drawGrid();

});